#  0. Générer graphiques Plotly
import csv
import plotly.express as px

#  1. Charger les données
def load_data(file_path):
    ventes = {}

    with open(file_path, "r") as file:
        reader = csv.reader(file)
        next(reader)  # skip header

        for row in reader:
            produit = row[1]
            qte = int(row[3])

            if produit in ventes:
                ventes[produit] += qte
            else:
                ventes[produit] = qte

    return ventes

# 2. Analyse des ventes
def analyze_sales(ventes):
    produit_max = max(ventes, key=ventes.get)
    produit_min = min(ventes, key=ventes.get)

    return {
        "max": (produit_max, ventes[produit_max]),
        "min": (produit_min, ventes[produit_min])
    }

#  3. Générer graphique Plotly
def generate_chart(ventes):
    produits = list(ventes.keys())
    quantites = list(ventes.values())

    fig = px.bar(
        x=produits,
        y=quantites,
        labels={"x": "Produit", "y": "Quantité vendue"},
        title="Volume des ventes par produit"
    )

    return fig

#  4. Générer HTML avec graphique intégré
def export_html(resultats, ventes, fig, output_file="31-resultats.html"):
    produit_max, qte_max = resultats["max"]
    produit_min, qte_min = resultats["min"]

    # convertir graphique en HTML
    graph_html = fig.to_html(full_html=False)

    html_content = f"""
    <html>
    <head>
        <title>Analyse des ventes ... BIS > Plotly Touch</title>
    </head>
    <body>
        <h1>Analyse des ventes</h1>

        <h2>Résultats principaux</h2>
        <p><strong>Produit le plus vendu :</strong> {produit_max} ({qte_max} unités)</p>
        <p><strong>Produit le moins vendu :</strong> {produit_min} ({qte_min} unités)</p>

        <h2>Détails des ventes</h2>
        <ul>
    """

    for produit, qte in ventes.items():
        html_content += f"<li>{produit} : {qte} unités</li>"

    html_content += f"""
        </ul>

        <h2>Graphique</h2>
        {graph_html}

    </body>
    </html>
    """

    with open(output_file, "w") as file:
        file.write(html_content)

# 5. main (point d'entrée)

    resultats = analyze_sales(ventes)
    fig = generate_chart(ventes)

    export_html(resultats, ventes, fig)

    print("✅ Analyse terminée et fichier HTML généré !")


def generate_charts(ventes, file_path):
    # 🔹 Préparer données pour CA
    ca_par_produit = {}

    with open(file_path, "r") as file:
        reader = csv.reader(file)
        next(reader)

        for row in reader:
            produit = row[1]
            prix = float(row[2])
            qte = int(row[3])

            ca = prix * qte

            if produit in ca_par_produit:
                ca_par_produit[produit] += ca
            else:
                ca_par_produit[produit] = ca

    # 🔹 Données
    produits = list(ventes.keys())
    quantites = list(ventes.values())
    ca_values = [ca_par_produit[p] for p in produits]